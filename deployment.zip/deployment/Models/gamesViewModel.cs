﻿using System.Collections.Generic;

namespace sykeplayer_1.Models
{
    public class gamesViewModel
    {
        public List<GameModel> GameModels { get; set; }
        
        public GameModel GameModel { get; set; }
    }
}