﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace sykeplayer_1.Data.Migrations
{
    public partial class InitialPostgres : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
