﻿namespace sykeplayer_1.Models
{
    public class IndexInfo
    {
        public string Html { get; set; }
        
        public string Id { get; set; }
    }
}